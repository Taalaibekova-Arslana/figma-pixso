import scss from "./Welcome.module.scss";
import Rectangle from "../../../assets/Rectangle.svg";
import Frame from "../../../assets/Frame 25.svg";
import img1 from "../../../assets/brand/Layer 1.svg";
import img2 from "../../../assets/brand/2.svg";
import img3 from "../../../assets/brand/image 14.svg";
import img4 from "../../../assets/brand/4.svg";
import img5 from "../../../assets/brand/image 16.svg";
import img6 from "../../../assets/brand/6.svg";
import img7 from "../../../assets/brand/7.svg";

const Welcome = () => {
	return (
		<div className={scss.Welcome}>
			<div className="container">
				<div className={scss.content}>
					<div className={scss.text1}>
						<div>
							<p>Рекламное агенство ADVUP</p>
							<h1>Новый поток клиентов Вашему продукту</h1>
						</div>
						<div className={scss.left}>
							<img className={scss.img} src={Rectangle} alt="" />
							<button>Приступим</button>
						</div>
					</div>
					<div className={scss.image}>
						<img className={scss.image2} src={Frame} alt="" />
					</div>
					<div className={scss.background1}>
						<div className={scss.background}>
							<img src={img1} alt="" />
							<img src={img2} alt="" />
							<img src={img3} alt="" />
							<img src={img4} alt="" />
							<img src={img5} alt="" />
							<img src={img6} alt="" />
							<img src={img7} alt="" />
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Welcome;

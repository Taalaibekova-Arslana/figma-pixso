import Section2 from "./HomeSections/Section2";
import Section3 from "./HomeSections/Section3";
import Welcome from "./HomeSections/Welcome";

const HomePage = () => {
	return (
		<>
			<Welcome />
			<Section2 />
			<Section3 />
		</>
	);
};

export default HomePage;
